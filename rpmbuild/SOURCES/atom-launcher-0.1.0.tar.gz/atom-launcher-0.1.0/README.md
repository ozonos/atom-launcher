Atom Launcher
=========

A simplified App Launcher with applications sorted by frequency of use
